package com.example.service

import android.content.Context
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.CountDownTimer
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.example.data.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

@UnstableApi
class MusicController(private val context: Context) {
    private var exoPlayer: ExoPlayer? = null
    private var equalizer: Equalizer? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var progressUpdateJob: Job? = null
    private var sleepTimer: CountDownTimer? = null

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _playlist = MutableStateFlow<List<Song>>(emptyList())
    val playlist: StateFlow<List<Song>> = _playlist.asStateFlow()

    private val _currentIndex = MutableStateFlow(-1)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _isShuffleEnabled = MutableStateFlow(false)
    val isShuffleEnabled: StateFlow<Boolean> = _isShuffleEnabled.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_OFF) // OFF, ONE, ALL
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _sleepTimerMinutes = MutableStateFlow(0)
    val sleepTimerMinutes: StateFlow<Int> = _sleepTimerMinutes.asStateFlow()

    private val _sleepTimerRemainingSec = MutableStateFlow(0L)
    val sleepTimerRemainingSec: StateFlow<Long> = _sleepTimerRemainingSec.asStateFlow()

    private val _eqPresetName = MutableStateFlow("Normal")
    val eqPresetName: StateFlow<String> = _eqPresetName.asStateFlow()

    private val _eqBands = MutableStateFlow<List<Int>>(listOf(0, 0, 0, 0, 0)) // dB levels (-10 to +10)
    val eqBands: StateFlow<List<Int>> = _eqBands.asStateFlow()

    init {
        initPlayer()
    }

    private fun initPlayer() {
        val player = ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
            shuffleModeEnabled = false
            addListener(object : Player.Listener {
                override fun onIsPlayingChanged(playing: Boolean) {
                    _isPlaying.value = playing
                    if (playing) {
                        startProgressUpdates()
                    } else {
                        stopProgressUpdates()
                    }
                }

                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    val index = this@apply.currentMediaItemIndex
                    _currentIndex.value = index
                    if (index in _playlist.value.indices) {
                        _currentSong.value = _playlist.value[index]
                    }
                    _duration.value = this@apply.duration.coerceAtLeast(0L)
                }

                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) {
                        _duration.value = this@apply.duration.coerceAtLeast(0L)
                        setupEqualizer(this@apply.audioSessionId)
                    }
                }
            })
        }
        exoPlayer = player
    }

    private fun setupEqualizer(audioSessionId: Int) {
        if (audioSessionId != C.AUDIO_SESSION_ID_UNSET) {
            try {
                equalizer?.release()
                equalizer = Equalizer(0, audioSessionId).apply {
                    enabled = true
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun playSongs(songs: List<Song>, startIndex: Int = 0) {
        if (songs.isEmpty()) return
        _playlist.value = songs
        _currentIndex.value = startIndex
        val songToPlay = songs[startIndex]
        _currentSong.value = songToPlay

        val player = exoPlayer ?: return
        player.stop()
        player.clearMediaItems()

        val mediaItems = songs.map { song ->
            val metadata = MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setAlbumTitle(song.album)
                .setArtworkUri(song.artworkUri?.let { Uri.parse(it) })
                .build()

            MediaItem.Builder()
                .setUri(Uri.parse(song.mediaUri))
                .setMediaMetadata(metadata)
                .setMediaId(song.id.toString())
                .build()
        }

        player.setMediaItems(mediaItems, startIndex, 0L)
        player.prepare()
        player.play()
    }

    fun playPause() {
        val player = exoPlayer ?: return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_ENDED) {
                player.seekTo(0, 0L)
            }
            player.play()
        }
    }

    fun playNext() {
        val player = exoPlayer ?: return
        if (player.hasNextMediaItem()) {
            player.seekToNextMediaItem()
        } else if (_playlist.value.isNotEmpty()) {
            player.seekTo(0, 0L)
        }
    }

    fun playPrevious() {
        val player = exoPlayer ?: return
        if (player.currentPosition > 3000) {
            player.seekTo(0)
        } else if (player.hasPreviousMediaItem()) {
            player.seekToPreviousMediaItem()
        } else {
            player.seekTo(0)
        }
    }

    fun seekTo(positionMs: Long) {
        exoPlayer?.seekTo(positionMs)
        _currentPosition.value = positionMs
    }

    fun toggleShuffle() {
        val player = exoPlayer ?: return
        val newShuffle = !player.shuffleModeEnabled
        player.shuffleModeEnabled = newShuffle
        _isShuffleEnabled.value = newShuffle
    }

    fun cycleRepeatMode() {
        val player = exoPlayer ?: return
        val nextMode = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        player.repeatMode = nextMode
        _repeatMode.value = nextMode
    }

    fun setSpeed(speed: Float) {
        _playbackSpeed.value = speed
        exoPlayer?.playbackParameters = PlaybackParameters(speed)
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimer?.cancel()
        _sleepTimerMinutes.value = minutes
        if (minutes <= 0) {
            _sleepTimerRemainingSec.value = 0L
            return
        }

        val millis = minutes * 60 * 1000L
        sleepTimer = object : CountDownTimer(millis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                _sleepTimerRemainingSec.value = millisUntilFinished / 1000
            }

            override fun onFinish() {
                _sleepTimerMinutes.value = 0
                _sleepTimerRemainingSec.value = 0L
                exoPlayer?.pause()
            }
        }.start()
    }

    fun setEqualizerPreset(presetName: String) {
        _eqPresetName.value = presetName
        val bands = when (presetName) {
            "Bass Boost" -> listOf(6, 4, 1, -1, -2)
            "Rock" -> listOf(5, 3, -1, 3, 5)
            "Pop" -> listOf(-1, 2, 5, 3, -2)
            "Jazz" -> listOf(3, 2, 1, 2, 4)
            "Vocal" -> listOf(-2, 1, 4, 3, 0)
            else -> listOf(0, 0, 0, 0, 0) // Normal / Flat
        }
        _eqBands.value = bands
        applyEqBands(bands)
    }

    fun updateEqBand(index: Int, levelDb: Int) {
        val current = _eqBands.value.toMutableList()
        if (index in current.indices) {
            current[index] = levelDb
            _eqBands.value = current
            _eqPresetName.value = "Custom"
            applyEqBands(current)
        }
    }

    private fun applyEqBands(bands: List<Int>) {
        val eq = equalizer ?: return
        try {
            val numBands = eq.numberOfBands.toInt()
            val minEq = eq.bandLevelRange[0]
            val maxEq = eq.bandLevelRange[1]
            for (i in 0 until minOf(numBands, bands.size)) {
                val db = bands[i]
                // Map -10..+10 dB to minEq..maxEq millibels
                val milliBels = (db * 100).coerceIn(minEq.toInt(), maxEq.toInt()).toShort()
                eq.setBandLevel(i.toShort(), milliBels)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startProgressUpdates() {
        stopProgressUpdates()
        progressUpdateJob = scope.launch {
            while (true) {
                exoPlayer?.let { player ->
                    if (player.isPlaying) {
                        _currentPosition.value = player.currentPosition
                        _duration.value = player.duration.coerceAtLeast(0L)
                    }
                }
                delay(500)
            }
        }
    }

    private fun stopProgressUpdates() {
        progressUpdateJob?.cancel()
        progressUpdateJob = null
    }

    fun release() {
        stopProgressUpdates()
        sleepTimer?.cancel()
        equalizer?.release()
        exoPlayer?.release()
        exoPlayer = null
    }
}
