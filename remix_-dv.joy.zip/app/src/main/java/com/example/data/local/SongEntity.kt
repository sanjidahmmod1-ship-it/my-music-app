package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.Song

@Entity(tableName = "songs")
data class SongEntity(
    @PrimaryKey val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val mediaUri: String,
    val artworkUri: String?,
    val isFavorite: Boolean,
    val dateAdded: Long,
    val playCount: Int
) {
    fun toSong(): Song = Song(
        id = id,
        title = title,
        artist = artist,
        album = album,
        durationMs = durationMs,
        mediaUri = mediaUri,
        artworkUri = artworkUri,
        isFavorite = isFavorite,
        dateAdded = dateAdded,
        playCount = playCount
    )

    companion object {
        fun fromSong(song: Song): SongEntity = SongEntity(
            id = song.id,
            title = song.title,
            artist = song.artist,
            album = song.album,
            durationMs = song.durationMs,
            mediaUri = song.mediaUri,
            artworkUri = song.artworkUri,
            isFavorite = song.isFavorite,
            dateAdded = song.dateAdded,
            playCount = song.playCount
        )
    }
}
