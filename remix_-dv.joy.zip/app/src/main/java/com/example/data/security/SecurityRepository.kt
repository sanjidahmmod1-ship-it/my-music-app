package com.example.data.security

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class LockType(val displayName: String) {
    PIN("PIN Code"),
    PATTERN("Pattern Lock"),
    FINGERPRINT("Fingerprint Lock"),
    FACE("Face Lock")
}

class SecurityRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("dvjoy_security_prefs", Context.MODE_PRIVATE)

    private val _isLockEnabled = MutableStateFlow(prefs.getBoolean(KEY_LOCK_ENABLED, false))
    val isLockEnabled: StateFlow<Boolean> = _isLockEnabled.asStateFlow()

    private val _lockType = MutableStateFlow(
        LockType.valueOf(prefs.getString(KEY_LOCK_TYPE, LockType.PIN.name) ?: LockType.PIN.name)
    )
    val lockType: StateFlow<LockType> = _lockType.asStateFlow()

    private val _hasSetPassword = MutableStateFlow(hasStoredPassword())
    val hasSetPassword: StateFlow<Boolean> = _hasSetPassword.asStateFlow()

    fun setLockEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_LOCK_ENABLED, enabled).apply()
        _isLockEnabled.value = enabled
    }

    fun setLockType(type: LockType) {
        prefs.edit().putString(KEY_LOCK_TYPE, type.name).apply()
        _lockType.value = type
    }

    fun setPinCode(pin: String) {
        prefs.edit().putString(KEY_PIN_CODE, pin).apply()
        _hasSetPassword.value = true
    }

    fun getPinCode(): String {
        return prefs.getString(KEY_PIN_CODE, "") ?: ""
    }

    fun setPatternCode(patternNodes: List<Int>) {
        val patternStr = patternNodes.joinToString(",")
        prefs.edit().putString(KEY_PATTERN_CODE, patternStr).apply()
        _hasSetPassword.value = true
    }

    fun getPatternCode(): List<Int> {
        val str = prefs.getString(KEY_PATTERN_CODE, "") ?: ""
        if (str.isBlank()) return emptyList()
        return str.split(",").mapNotNull { it.trim().toIntOrNull() }
    }

    fun setSecurityQuestionAndAnswer(question: String, answer: String) {
        prefs.edit()
            .putString(KEY_SECURITY_QUESTION, question)
            .putString(KEY_SECURITY_ANSWER, answer.lowercase().trim())
            .apply()
    }

    fun getSecurityQuestion(): String {
        return prefs.getString(KEY_SECURITY_QUESTION, "What is your favorite song or artist?") ?: "What is your favorite song or artist?"
    }

    fun validateSecurityAnswer(answer: String): Boolean {
        val stored = prefs.getString(KEY_SECURITY_ANSWER, "") ?: ""
        if (stored.isBlank()) return true // default allow if not set
        return stored.equals(answer.lowercase().trim(), ignoreCase = true)
    }

    fun validatePin(enteredPin: String): Boolean {
        val storedPin = getPinCode()
        if (storedPin.isBlank()) return true
        return storedPin == enteredPin
    }

    fun validatePattern(enteredPattern: List<Int>): Boolean {
        val storedPattern = getPatternCode()
        if (storedPattern.isEmpty()) return true
        return storedPattern == enteredPattern
    }

    fun hasStoredPassword(): Boolean {
        return getPinCode().isNotBlank() || getPatternCode().isNotEmpty()
    }

    fun resetLock() {
        prefs.edit().clear().apply()
        _isLockEnabled.value = false
        _lockType.value = LockType.PIN
        _hasSetPassword.value = false
    }

    companion object {
        private const val KEY_LOCK_ENABLED = "key_lock_enabled"
        private const val KEY_LOCK_TYPE = "key_lock_type"
        private const val KEY_PIN_CODE = "key_pin_code"
        private const val KEY_PATTERN_CODE = "key_pattern_code"
        private const val KEY_SECURITY_QUESTION = "key_security_question"
        private const val KEY_SECURITY_ANSWER = "key_security_answer"
    }
}
