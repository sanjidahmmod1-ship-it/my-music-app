package com.example.data.repository

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.example.data.local.DVJoyDatabase
import com.example.data.local.HistoryEntity
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistSongCrossRef
import com.example.data.local.SongEntity
import com.example.data.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class MusicRepository(private val context: Context) {
    private val db = DVJoyDatabase.getInstance(context)
    private val songDao = db.songDao()
    private val playlistDao = db.playlistDao()

    val allSongs: Flow<List<Song>> = songDao.getAllSongs().map { list ->
        list.map { it.toSong() }
    }

    val favoriteSongs: Flow<List<Song>> = songDao.getFavoriteSongs().map { list ->
        list.map { it.toSong() }
    }

    val recentlyPlayed: Flow<List<Song>> = songDao.getRecentlyPlayedSongs().map { list ->
        list.map { it.toSong() }
    }

    val playlists: Flow<List<PlaylistEntity>> = playlistDao.getAllPlaylists()

    suspend fun toggleFavorite(songId: Long, currentIsFavorite: Boolean) {
        songDao.setFavorite(songId, !currentIsFavorite)
    }

    suspend fun recordSongPlayed(songId: Long) {
        songDao.incrementPlayCount(songId)
        songDao.insertHistory(HistoryEntity(songId = songId, playedAt = System.currentTimeMillis()))
    }

    suspend fun createPlaylist(name: String): Long {
        return playlistDao.createPlaylist(PlaylistEntity(name = name))
    }

    suspend fun addSongToPlaylist(playlistId: Long, songId: Long) {
        playlistDao.addSongToPlaylist(PlaylistSongCrossRef(playlistId, songId))
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        playlistDao.removeSongFromPlaylist(playlistId, songId)
    }

    fun getSongsForPlaylist(playlistId: Long): Flow<List<Song>> {
        return playlistDao.getSongsForPlaylist(playlistId).map { list ->
            list.map { it.toSong() }
        }
    }

    suspend fun clearHistory() {
        songDao.clearHistory()
    }

    suspend fun scanLocalSongs(): Int = withContext(Dispatchers.IO) {
        val scannedSongs = mutableListOf<SongEntity>()

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        try {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val albumIdColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val title = cursor.getString(titleColumn) ?: "Unknown Track"
                    val artist = cursor.getString(artistColumn) ?: "Unknown Artist"
                    val album = cursor.getString(albumColumn) ?: "Unknown Album"
                    val duration = cursor.getLong(durationColumn)
                    val albumId = cursor.getLong(albumIdColumn)

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    ).toString()

                    val albumArtUri = ContentUris.withAppendedId(
                        android.net.Uri.parse("content://media/external/audio/albumart"),
                        albumId
                    ).toString()

                    val existing = songDao.getSongById(id)
                    val isFav = existing?.isFavorite ?: false

                    scannedSongs.add(
                        SongEntity(
                            id = id,
                            title = title,
                            artist = if (artist == "<unknown>") "DV.JOY Audio" else artist,
                            album = if (album == "<unknown>") "Single" else album,
                            durationMs = if (duration > 0) duration else 180000L,
                            mediaUri = contentUri,
                            artworkUri = albumArtUri,
                            isFavorite = isFav,
                            dateAdded = System.currentTimeMillis(),
                            playCount = existing?.playCount ?: 0
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // If no local songs were found on the device, populate high-quality default tracks as fallback
        if (scannedSongs.isEmpty()) {
            val demoSongs = getDemoFallbackSongs()
            songDao.insertSongs(demoSongs)
            return@withContext demoSongs.size
        } else {
            songDao.insertSongs(scannedSongs)
            return@withContext scannedSongs.size
        }
    }

    private fun getDemoFallbackSongs(): List<SongEntity> {
        val albumCover1 = "android.resource://${context.packageName}/drawable/img_album_cover_1_1784724867515"
        val albumCover2 = "android.resource://${context.packageName}/drawable/img_album_cover_2_1784724879862"
        val logoCover = "android.resource://${context.packageName}/drawable/img_dvjoy_logo_1784724845424"

        return listOf(
            SongEntity(
                id = 1001L,
                title = "Neon Horizon",
                artist = "DV.JOY Cyber",
                album = "Electric Dreams",
                durationMs = 214000L,
                mediaUri = "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp3",
                artworkUri = albumCover1,
                isFavorite = true,
                dateAdded = System.currentTimeMillis() - 86400000,
                playCount = 12
            ),
            SongEntity(
                id = 1002L,
                title = "Cybernetic Pulse",
                artist = "Synthwave Collective",
                album = "Midnight Glass",
                durationMs = 185000L,
                mediaUri = "https://storage.googleapis.com/gtv-videos-bucket/sample/SubtleThought.mp3",
                artworkUri = albumCover2,
                isFavorite = false,
                dateAdded = System.currentTimeMillis() - 172800000,
                playCount = 8
            ),
            SongEntity(
                id = 1003L,
                title = "Glassmorphism Lounge",
                artist = "Aura Blue",
                album = "Deep Indigo",
                durationMs = 240000L,
                mediaUri = "https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp3",
                artworkUri = logoCover,
                isFavorite = true,
                dateAdded = System.currentTimeMillis() - 259200000,
                playCount = 15
            ),
            SongEntity(
                id = 1004L,
                title = "Blue Velocity",
                artist = "DV.JOY Beats",
                album = "Sonic Wave",
                durationMs = 198000L,
                mediaUri = "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp3",
                artworkUri = albumCover1,
                isFavorite = false,
                dateAdded = System.currentTimeMillis() - 345600000,
                playCount = 5
            ),
            SongEntity(
                id = 1005L,
                title = "Starlight Reverie",
                artist = "Luna Resonance",
                album = "Chill Outlines",
                durationMs = 222000L,
                mediaUri = "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp3",
                artworkUri = albumCover2,
                isFavorite = true,
                dateAdded = System.currentTimeMillis() - 432000000,
                playCount = 20
            )
        )
    }
}
