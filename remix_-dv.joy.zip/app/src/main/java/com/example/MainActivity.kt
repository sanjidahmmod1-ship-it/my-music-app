package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.fragment.app.FragmentActivity
import com.example.ui.screens.AppLockOverlayScreen
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import com.example.data.model.Song
import com.example.ui.components.AddToPlaylistDialog
import com.example.ui.components.MiniPlayer
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.screens.PlaylistScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.DVJoyTheme
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MusicViewModel

@UnstableApi
class MainActivity : FragmentActivity() {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.values.all { it }
        if (granted) {
            Toast.makeText(this, "Permissions Granted. Scanning local music...", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        checkAndRequestPermissions()

        setContent {
            DVJoyTheme {
                DVJoyMainApp()
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }
}

@UnstableApi
@Composable
fun DVJoyMainApp(
    viewModel: MusicViewModel = viewModel()
) {
    var showSplash by remember { mutableStateOf(true) }
    val isLockEnabled by viewModel.securityRepository.isLockEnabled.collectAsState()
    val isAppUnlocked by viewModel.isAppUnlocked.collectAsState()

    val currentTab by viewModel.currentTab.collectAsState()
    val currentSong by viewModel.currentSong.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val currentPosition by viewModel.currentPosition.collectAsState()
    val duration by viewModel.duration.collectAsState()
    val isPlayerExpanded by viewModel.isPlayerExpanded.collectAsState()
    val playlists by viewModel.playlists.collectAsState()

    var songToAddToPlaylist by remember { mutableStateOf<Song?>(null) }

    if (showSplash) {
        SplashScreen(onSplashFinished = { showSplash = false })
    } else if (isLockEnabled && !isAppUnlocked) {
        AppLockOverlayScreen(
            securityRepository = viewModel.securityRepository,
            onUnlocked = { viewModel.setAppUnlocked(true) }
        )
    } else {
        Box(modifier = Modifier.fillMaxSize()) {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                bottomBar = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                    ) {
                        // Floating Mini Player above Bottom Bar
                        if (currentSong != null && !isPlayerExpanded) {
                            MiniPlayer(
                                song = currentSong,
                                isPlaying = isPlaying,
                                currentPosition = currentPosition,
                                duration = duration,
                                onPlayPause = { viewModel.playPause() },
                                onNext = { viewModel.playNext() },
                                onToggleFavorite = { viewModel.toggleFavorite(it) },
                                onExpand = { viewModel.togglePlayerExpanded(true) }
                            )
                        }

                        // Bottom Navigation Bar
                        NavigationBar(
                            containerColor = Color(0xEE0A111F),
                            contentColor = NeonCyan,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                                .testTag("bottom_navigation_bar")
                        ) {
                            NavigationBarItem(
                                selected = currentTab == MainTab.HOME,
                                onClick = { viewModel.selectTab(MainTab.HOME) },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                label = { Text("Home", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NeonCyan,
                                    selectedTextColor = NeonCyan,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary,
                                    indicatorColor = Color(0x3300E5FF)
                                ),
                                modifier = Modifier.testTag("nav_home")
                            )

                            NavigationBarItem(
                                selected = currentTab == MainTab.LIBRARY,
                                onClick = { viewModel.selectTab(MainTab.LIBRARY) },
                                icon = { Icon(Icons.Default.LibraryMusic, contentDescription = "Library") },
                                label = { Text("Library", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NeonCyan,
                                    selectedTextColor = NeonCyan,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary,
                                    indicatorColor = Color(0x3300E5FF)
                                ),
                                modifier = Modifier.testTag("nav_library")
                            )

                            NavigationBarItem(
                                selected = currentTab == MainTab.PLAYLIST,
                                onClick = { viewModel.selectTab(MainTab.PLAYLIST) },
                                icon = { Icon(Icons.Default.QueueMusic, contentDescription = "Playlist") },
                                label = { Text("Playlist", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NeonCyan,
                                    selectedTextColor = NeonCyan,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary,
                                    indicatorColor = Color(0x3300E5FF)
                                ),
                                modifier = Modifier.testTag("nav_playlist")
                            )

                            NavigationBarItem(
                                selected = currentTab == MainTab.FAVORITES,
                                onClick = { viewModel.selectTab(MainTab.FAVORITES) },
                                icon = { Icon(Icons.Default.Favorite, contentDescription = "Favorites") },
                                label = { Text("Favorites", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NeonCyan,
                                    selectedTextColor = NeonCyan,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary,
                                    indicatorColor = Color(0x3300E5FF)
                                ),
                                modifier = Modifier.testTag("nav_favorites")
                            )

                            NavigationBarItem(
                                selected = currentTab == MainTab.SETTINGS,
                                onClick = { viewModel.selectTab(MainTab.SETTINGS) },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text("Settings", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NeonCyan,
                                    selectedTextColor = NeonCyan,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary,
                                    indicatorColor = Color(0x3300E5FF)
                                ),
                                modifier = Modifier.testTag("nav_settings")
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (currentTab) {
                        MainTab.HOME -> HomeScreen(
                            viewModel = viewModel,
                            onOpenPlaylists = { viewModel.selectTab(MainTab.PLAYLIST) },
                            onOpenPlaylistDialog = { songToAddToPlaylist = it }
                        )
                        MainTab.LIBRARY -> LibraryScreen(
                            viewModel = viewModel,
                            onOpenPlaylistDialog = { songToAddToPlaylist = it }
                        )
                        MainTab.PLAYLIST -> PlaylistScreen(
                            viewModel = viewModel,
                            onOpenPlaylistDialog = { songToAddToPlaylist = it }
                        )
                        MainTab.FAVORITES -> FavoritesScreen(
                            viewModel = viewModel,
                            onOpenPlaylistDialog = { songToAddToPlaylist = it }
                        )
                        MainTab.SETTINGS -> SettingsScreen(
                            viewModel = viewModel
                        )
                    }
                }
            }

            // Expanded Player View Over Screen
            AnimatedVisibility(
                visible = isPlayerExpanded,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                PlayerScreen(
                    viewModel = viewModel,
                    onCollapse = { viewModel.togglePlayerExpanded(false) }
                )
            }

            // Add To Playlist Dialog
            if (songToAddToPlaylist != null) {
                AddToPlaylistDialog(
                    song = songToAddToPlaylist!!,
                    playlists = playlists,
                    onSelectPlaylist = { playlist ->
                        viewModel.addSongToPlaylist(playlist.id, songToAddToPlaylist!!.id)
                        songToAddToPlaylist = null
                    },
                    onDismiss = { songToAddToPlaylist = null }
                )
            }
        }
    }
}
