package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.NeonCyan
import kotlin.math.hypot

@Composable
fun PatternLockCanvas(
    selectedNodes: List<Int>,
    onNodeSelected: (Int) -> Unit,
    onPatternComplete: (List<Int>) -> Unit,
    isError: Boolean = false,
    modifier: Modifier = Modifier
) {
    var currentTouchPosition by remember { mutableStateOf<Offset?>(null) }

    val activeColor = if (isError) Color.Red else NeonCyan
    val inactiveColor = GlassBorder

    Box(
        modifier = modifier
            .size(280.dp)
            .testTag("pattern_lock_canvas")
    ) {
        Canvas(
            modifier = Modifier
                .size(280.dp)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            currentTouchPosition = offset
                            val node = getNodeIndexAtOffset(offset, size.width.toFloat())
                            if (node != null && !selectedNodes.contains(node)) {
                                onNodeSelected(node)
                            }
                        },
                        onDrag = { change, _ ->
                            val offset = change.position
                            currentTouchPosition = offset
                            val node = getNodeIndexAtOffset(offset, size.width.toFloat())
                            if (node != null && !selectedNodes.contains(node)) {
                                onNodeSelected(node)
                            }
                        },
                        onDragEnd = {
                            currentTouchPosition = null
                            onPatternComplete(selectedNodes)
                        },
                        onDragCancel = {
                            currentTouchPosition = null
                            onPatternComplete(selectedNodes)
                        }
                    )
                }
        ) {
            val canvasSize = size.width
            val cellSize = canvasSize / 3f
            val nodeRadius = 14.dp.toPx()
            val touchRadius = 36.dp.toPx()

            // Calculate center offsets for all 9 grid points (0..8)
            val nodeCenters = List(9) { idx ->
                val col = idx % 3
                val row = idx / 3
                Offset(
                    x = cellSize * col + cellSize / 2f,
                    y = cellSize * row + cellSize / 2f
                )
            }

            // Draw lines between selected nodes
            if (selectedNodes.isNotEmpty()) {
                val path = Path()
                path.moveTo(nodeCenters[selectedNodes.first()].x, nodeCenters[selectedNodes.first()].y)

                for (i in 1 until selectedNodes.size) {
                    val nextCenter = nodeCenters[selectedNodes[i]]
                    path.lineTo(nextCenter.x, nextCenter.y)
                }

                // Line to current touch position if dragging
                currentTouchPosition?.let { touch ->
                    val lastCenter = nodeCenters[selectedNodes.last()]
                    path.lineTo(touch.x, touch.y)
                }

                drawPath(
                    path = path,
                    color = activeColor,
                    style = Stroke(
                        width = 8.dp.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }

            // Draw 9 Dots
            nodeCenters.forEachIndexed { index, center ->
                val isSelected = selectedNodes.contains(index)

                if (isSelected) {
                    // Outer glowing halo circle
                    drawCircle(
                        color = activeColor.copy(alpha = 0.3f),
                        radius = touchRadius,
                        center = center
                    )
                    // Active node stroke
                    drawCircle(
                        color = activeColor,
                        radius = nodeRadius,
                        center = center,
                        style = Stroke(width = 4.dp.toPx())
                    )
                    // Inner dot
                    drawCircle(
                        color = activeColor,
                        radius = nodeRadius / 2f,
                        center = center
                    )
                } else {
                    // Inactive Dot
                    drawCircle(
                        color = inactiveColor,
                        radius = 8.dp.toPx(),
                        center = center
                    )
                }
            }
        }
    }
}

private fun getNodeIndexAtOffset(offset: Offset, canvasWidth: Float): Int? {
    val cellSize = canvasWidth / 3f
    val hitRadius = cellSize * 0.45f

    for (i in 0 until 9) {
        val col = i % 3
        val row = i / 3
        val nodeCenter = Offset(
            x = cellSize * col + cellSize / 2f,
            y = cellSize * row + cellSize / 2f
        )

        val dx = offset.x - nodeCenter.x
        val dy = offset.y - nodeCenter.y
        val distance = hypot(dx, dy)

        if (distance <= hitRadius) {
            return i
        }
    }
    return null
}
