package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CardBackground
import com.example.ui.theme.CardBorder
import com.example.ui.theme.GlowBlue

@Composable
fun GlassmorphicCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    backgroundColor: Color = CardBackground,
    borderColor: Color = CardBorder,
    borderWidth: Dp = 1.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val glassBrush = Brush.verticalGradient(
        colors = listOf(
            backgroundColor,
            backgroundColor.copy(alpha = 0.15f)
        )
    )

    val borderBrush = Brush.linearGradient(
        colors = listOf(
            borderColor,
            borderColor.copy(alpha = 0.1f)
        )
    )

    var cardModifier = modifier
        .shadow(elevation = 12.dp, shape = shape, spotColor = GlowBlue)
        .clip(shape)
        .background(glassBrush)
        .border(width = borderWidth, brush = borderBrush, shape = shape)

    if (onClick != null) {
        cardModifier = cardModifier.clickable { onClick() }
    }

    Box(
        modifier = cardModifier,
        content = content
    )
}
