package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.QuestionMark
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.security.LockType
import com.example.data.security.SecurityRepository
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.PatternLockCanvas
import com.example.ui.components.PinInputPad
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecuritySettingsSheet(
    securityRepository: SecurityRepository,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isLockEnabled by securityRepository.isLockEnabled.collectAsState()
    val lockType by securityRepository.lockType.collectAsState()
    val hasSetPassword by securityRepository.hasSetPassword.collectAsState()

    var showPinSetupDialog by remember { mutableStateOf(false) }
    var showPatternSetupDialog by remember { mutableStateOf(false) }
    var showRecoverySetupDialog by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = DarkBackground,
        scrimColor = Color.Black.copy(alpha = 0.6f)
    ) {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .padding(24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "App Lock",
                    tint = NeonCyan,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "App Lock Security",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Protect PLAY AND FEEL with PIN, Fingerprint or Face Lock",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
            }

            // Enable App Lock Switch Card
            GlassmorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Enable App Lock",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            text = if (isLockEnabled) "App Lock is ACTIVE" else "App Lock is DISABLED",
                            fontSize = 12.sp,
                            color = if (isLockEnabled) NeonCyan else TextSecondary
                        )
                    }

                    Switch(
                        checked = isLockEnabled,
                        onCheckedChange = { enabled ->
                            if (enabled && !hasSetPassword) {
                                Toast.makeText(context, "Please set a PIN code first", Toast.LENGTH_SHORT).show()
                                showPinSetupDialog = true
                            } else {
                                securityRepository.setLockEnabled(enabled)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DarkBackground,
                            checkedTrackColor = NeonCyan,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = GlassSurface
                        ),
                        modifier = Modifier.testTag("switch_app_lock")
                    )
                }
            }

            Text(
                text = "SELECT LOCK METHOD",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = NeonCyan,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            // 1. PIN Lock Option
            LockMethodItem(
                icon = Icons.Default.Pin,
                title = "PIN Code Lock",
                subtitle = if (lockType == LockType.PIN && hasSetPassword) "Active • Change PIN" else "Set 4-digit PIN code",
                isSelected = lockType == LockType.PIN && isLockEnabled,
                onClick = {
                    securityRepository.setLockType(LockType.PIN)
                    showPinSetupDialog = true
                },
                tag = "method_pin"
            )

            // 2. Fingerprint Lock Option
            LockMethodItem(
                icon = Icons.Default.Fingerprint,
                title = "Fingerprint Lock",
                subtitle = "Use biometric fingerprint scanner",
                isSelected = lockType == LockType.FINGERPRINT && isLockEnabled,
                onClick = {
                    if (!hasSetPassword) {
                        Toast.makeText(context, "Set a PIN code backup first", Toast.LENGTH_SHORT).show()
                        showPinSetupDialog = true
                    } else {
                        securityRepository.setLockType(LockType.FINGERPRINT)
                        securityRepository.setLockEnabled(true)
                        Toast.makeText(context, "Fingerprint Lock Activated", Toast.LENGTH_SHORT).show()
                    }
                },
                tag = "method_fingerprint"
            )

            // 3. Face Lock Option
            LockMethodItem(
                icon = Icons.Default.Face,
                title = "Face Lock / Recognition",
                subtitle = "Use biometric facial recognition",
                isSelected = lockType == LockType.FACE && isLockEnabled,
                onClick = {
                    if (!hasSetPassword) {
                        Toast.makeText(context, "Set a PIN code backup first", Toast.LENGTH_SHORT).show()
                        showPinSetupDialog = true
                    } else {
                        securityRepository.setLockType(LockType.FACE)
                        securityRepository.setLockEnabled(true)
                        Toast.makeText(context, "Face Lock Activated", Toast.LENGTH_SHORT).show()
                    }
                },
                tag = "method_facelock"
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Recovery Question Setup Button
            GlassmorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showRecoverySetupDialog = true }
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.QuestionMark, contentDescription = "Recovery", tint = NeonCyan)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("Setup Recovery Question", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("Used to reset password if forgotten", fontSize = 11.sp, color = TextSecondary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // PIN Setup Dialog
    if (showPinSetupDialog) {
        var tempPin1 by remember { mutableStateOf("") }
        var tempPin2 by remember { mutableStateOf("") }
        var isConfirmStep by remember { mutableStateOf(false) }
        var pinError by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showPinSetupDialog = false },
            containerColor = DarkBackground,
            title = {
                Text(
                    text = if (!isConfirmStep) "Set 4-Digit PIN" else "Confirm Your PIN",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (!isConfirmStep) "Enter a 4-digit PIN code" else "Re-enter your 4-digit PIN to confirm",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    if (pinError.isNotEmpty()) {
                        Text(pinError, color = Color.Red, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                    }

                    PinInputPad(
                        pinLength = 4,
                        enteredPin = if (!isConfirmStep) tempPin1 else tempPin2,
                        onPinChange = { pin ->
                            if (!isConfirmStep) tempPin1 = pin else tempPin2 = pin
                            pinError = ""
                        },
                        onPinSubmitted = { pin ->
                            if (!isConfirmStep) {
                                isConfirmStep = true
                            } else {
                                if (pin == tempPin1) {
                                    securityRepository.setPinCode(pin)
                                    securityRepository.setLockEnabled(true)
                                    securityRepository.setLockType(LockType.PIN)
                                    Toast.makeText(context, "PIN code set successfully!", Toast.LENGTH_SHORT).show()
                                    showPinSetupDialog = false
                                } else {
                                    pinError = "PINs do not match! Try again."
                                    tempPin2 = ""
                                }
                            }
                        }
                    )
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showPinSetupDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Pattern Setup Dialog
    if (showPatternSetupDialog) {
        var pattern1 by remember { mutableStateOf<List<Int>>(emptyList()) }
        var isConfirmPattern by remember { mutableStateOf(false) }
        val currentPatternNodes = remember { mutableStateListOf<Int>() }
        var patternError by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showPatternSetupDialog = false },
            containerColor = DarkBackground,
            title = {
                Text(
                    text = if (!isConfirmPattern) "Draw Pattern" else "Confirm Pattern",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (!isConfirmPattern) "Connect at least 4 dots" else "Draw pattern again to confirm",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    if (patternError.isNotEmpty()) {
                        Text(patternError, color = Color.Red, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                    }

                    PatternLockCanvas(
                        selectedNodes = currentPatternNodes,
                        onNodeSelected = { node ->
                            currentPatternNodes.add(node)
                            patternError = ""
                        },
                        onPatternComplete = { drawn ->
                            if (drawn.size < 4) {
                                patternError = "Connect at least 4 dots!"
                                currentPatternNodes.clear()
                                return@PatternLockCanvas
                            }

                            if (!isConfirmPattern) {
                                pattern1 = drawn.toList()
                                isConfirmPattern = true
                                currentPatternNodes.clear()
                            } else {
                                if (drawn == pattern1) {
                                    securityRepository.setPatternCode(drawn)
                                    securityRepository.setLockEnabled(true)
                                    securityRepository.setLockType(LockType.PATTERN)
                                    Toast.makeText(context, "Pattern lock set successfully!", Toast.LENGTH_SHORT).show()
                                    showPatternSetupDialog = false
                                } else {
                                    patternError = "Patterns do not match! Try again."
                                    currentPatternNodes.clear()
                                }
                            }
                        }
                    )
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showPatternSetupDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Security Recovery Setup Dialog
    if (showRecoverySetupDialog) {
        var question by remember { mutableStateOf(securityRepository.getSecurityQuestion()) }
        var answer by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showRecoverySetupDialog = false },
            containerColor = DarkBackground,
            title = {
                Text("Security Recovery Question", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            },
            text = {
                Column {
                    Text("Security Question:", fontSize = 12.sp, color = TextSecondary)
                    OutlinedTextField(
                        value = question,
                        onValueChange = { question = it },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = GlassBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Answer:", fontSize = 12.sp, color = TextSecondary)
                    OutlinedTextField(
                        value = answer,
                        onValueChange = { answer = it },
                        placeholder = { Text("Your answer...", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = GlassBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (answer.isNotBlank()) {
                            securityRepository.setSecurityQuestionAndAnswer(question, answer)
                            Toast.makeText(context, "Security question saved!", Toast.LENGTH_SHORT).show()
                            showRecoverySetupDialog = false
                        } else {
                            Toast.makeText(context, "Please enter an answer", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("Save Question", color = DarkBackground, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRecoverySetupDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun LockMethodItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onClick() }
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) NeonCyan.copy(alpha = 0.2f) else GlassSurface)
                    .border(1.dp, if (isSelected) NeonCyan else GlassBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isSelected) NeonCyan else TextPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = if (isSelected) NeonCyan else TextSecondary
                )
            }

            if (isSelected) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(NeonCyan)
                )
            }
        }
    }
}
