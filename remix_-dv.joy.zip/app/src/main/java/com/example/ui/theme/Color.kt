package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BlackBackground = Color(0xFF080B11)
val DarkBackground = BlackBackground
val DeepNavy = Color(0xFF0E1626)
val GlassSurface = Color(0x221A263B)
val GlassSurfaceHighlight = Color(0x332B3E5C)
val GlassBorder = Color(0x3300E5FF)

val NeonCyan = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF0088FF)
val DeepBlueAccent = Color(0xFF0052CC)
val IceBlue = Color(0xFFE0F7FA)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val CardBackground = Color(0x2A152033)
val CardBorder = Color(0x2600E5FF)
val GlowBlue = Color(0x4000E5FF)
val FavoriteRed = Color(0xFFFF3B30)
