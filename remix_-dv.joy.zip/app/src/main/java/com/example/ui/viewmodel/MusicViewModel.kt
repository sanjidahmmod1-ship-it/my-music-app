package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import com.example.data.local.PlaylistEntity
import com.example.data.model.Song
import com.example.data.repository.MusicRepository
import com.example.service.MusicController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab {
    HOME,
    LIBRARY,
    PLAYLIST,
    FAVORITES,
    SETTINGS
}

@UnstableApi
class MusicViewModel(application: Application) : AndroidViewModel(application) {
    val repository = MusicRepository(application)
    val musicController = MusicController(application)
    val securityRepository = com.example.data.security.SecurityRepository(application)

    private val _isAppUnlocked = MutableStateFlow(!securityRepository.isLockEnabled.value)
    val isAppUnlocked: StateFlow<Boolean> = _isAppUnlocked.asStateFlow()

    fun setAppUnlocked(unlocked: Boolean) {
        _isAppUnlocked.value = unlocked
    }

    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _isPlayerExpanded = MutableStateFlow(false)
    val isPlayerExpanded: StateFlow<Boolean> = _isPlayerExpanded.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedPlaylist = MutableStateFlow<PlaylistEntity?>(null)
    val selectedPlaylist: StateFlow<PlaylistEntity?> = _selectedPlaylist.asStateFlow()

    val allSongs: StateFlow<List<Song>> = repository.allSongs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val favoriteSongs: StateFlow<List<Song>> = repository.favoriteSongs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val recentlyPlayed: StateFlow<List<Song>> = repository.recentlyPlayed.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val playlists: StateFlow<List<PlaylistEntity>> = repository.playlists.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val filteredSongs: StateFlow<List<Song>> = combine(allSongs, _searchQuery) { songs, query ->
        if (query.isBlank()) {
            songs
        } else {
            songs.filter { song ->
                song.title.contains(query, ignoreCase = true) ||
                        song.artist.contains(query, ignoreCase = true) ||
                        song.album.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Playback state forwarded from MusicController
    val currentSong = musicController.currentSong
    val isPlaying = musicController.isPlaying
    val currentPosition = musicController.currentPosition
    val duration = musicController.duration
    val isShuffleEnabled = musicController.isShuffleEnabled
    val repeatMode = musicController.repeatMode
    val playbackSpeed = musicController.playbackSpeed
    val sleepTimerMinutes = musicController.sleepTimerMinutes
    val sleepTimerRemainingSec = musicController.sleepTimerRemainingSec
    val eqPresetName = musicController.eqPresetName
    val eqBands = musicController.eqBands

    init {
        scanMusic()
    }

    fun scanMusic() {
        viewModelScope.launch {
            repository.scanLocalSongs()
        }
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun togglePlayerExpanded(expanded: Boolean) {
        _isPlayerExpanded.value = expanded
    }

    fun playSong(song: Song, playlistContext: List<Song> = allSongs.value) {
        val songsList = if (playlistContext.isNotEmpty()) playlistContext else listOf(song)
        val index = songsList.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        musicController.playSongs(songsList, index)
        viewModelScope.launch {
            repository.recordSongPlayed(song.id)
        }
    }

    fun playPause() {
        musicController.playPause()
    }

    fun playNext() {
        musicController.playNext()
        currentSong.value?.let { song ->
            viewModelScope.launch {
                repository.recordSongPlayed(song.id)
            }
        }
    }

    fun playPrevious() {
        musicController.playPrevious()
        currentSong.value?.let { song ->
            viewModelScope.launch {
                repository.recordSongPlayed(song.id)
            }
        }
    }

    fun seekTo(positionMs: Long) {
        musicController.seekTo(positionMs)
    }

    fun toggleShuffle() {
        musicController.toggleShuffle()
    }

    fun cycleRepeatMode() {
        musicController.cycleRepeatMode()
    }

    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            repository.toggleFavorite(song.id, song.isFavorite)
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        musicController.setSpeed(speed)
    }

    fun setSleepTimer(minutes: Int) {
        musicController.setSleepTimer(minutes)
    }

    fun setEqualizerPreset(presetName: String) {
        musicController.setEqualizerPreset(presetName)
    }

    fun updateEqBand(index: Int, dbLevel: Int) {
        musicController.updateEqBand(index, dbLevel)
    }

    fun createPlaylist(name: String) {
        viewModelScope.launch {
            repository.createPlaylist(name)
        }
    }

    fun addSongToPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            repository.addSongToPlaylist(playlistId, songId)
        }
    }

    fun selectPlaylist(playlist: PlaylistEntity?) {
        _selectedPlaylist.value = playlist
    }

    fun clearCache() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    override fun onCleared() {
        musicController.release()
        super.onCleared()
    }
}
