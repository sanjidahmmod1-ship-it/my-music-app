package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import com.example.R
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.GlassSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MusicViewModel

@OptIn(ExperimentalMaterial3Api::class)
@UnstableApi
@Composable
fun SettingsScreen(
    viewModel: MusicViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showAboutDialog by remember { mutableStateOf(false) }
    var showEqualizerSheet by remember { mutableStateOf(false) }
    var showSleepTimerSheet by remember { mutableStateOf(false) }
    var showSpeedSheet by remember { mutableStateOf(false) }
    var showSecuritySheet by remember { mutableStateOf(false) }

    val eqPresetName by viewModel.eqPresetName.collectAsState()
    val sleepTimerMin by viewModel.sleepTimerMinutes.collectAsState()
    val playbackSpeed by viewModel.playbackSpeed.collectAsState()
    val isLockEnabled by viewModel.securityRepository.isLockEnabled.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "Settings",
            fontSize = 28.sp,
            fontWeight = FontWeight.Black,
            color = TextPrimary,
            modifier = Modifier.padding(vertical = 16.dp)
        )

        // Glass Banner App Info
        GlassmorphicCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_dvjoy_logo_1784724845424),
                    contentDescription = "DV.JOY Logo",
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .border(1.dp, NeonCyan, CircleShape)
                )

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text("DV.JOY Music Player", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("Version 1.0.0 Pro • Glassmorphism Edition", fontSize = 12.sp, color = NeonCyan)
                }
            }
        }

        // Settings Items
        SettingItem(
            icon = Icons.Default.Palette,
            title = "Theme",
            subtitle = "Glassmorphism Dark Cyan (Default)",
            onClick = {
                Toast.makeText(context, "Dark Glassmorphism Theme Active", Toast.LENGTH_SHORT).show()
            },
            tag = "setting_theme"
        )

        SettingItem(
            icon = Icons.Default.Lock,
            title = "App Lock & Security",
            subtitle = if (isLockEnabled) "App Lock Active • Password / PIN / Biometric" else "Set PIN, Pattern, Fingerprint, or Face Lock",
            onClick = { showSecuritySheet = true },
            tag = "setting_security"
        )

        SettingItem(
            icon = Icons.Default.Equalizer,
            title = "Graphic Equalizer",
            subtitle = "Active Preset: $eqPresetName",
            onClick = { showEqualizerSheet = true },
            tag = "setting_equalizer"
        )

        SettingItem(
            icon = Icons.Default.Timer,
            title = "Sleep Timer",
            subtitle = if (sleepTimerMin > 0) "Timer set to $sleepTimerMin minutes" else "Timer Disabled",
            onClick = { showSleepTimerSheet = true },
            tag = "setting_sleep_timer"
        )

        SettingItem(
            icon = Icons.Default.Speed,
            title = "Playback Speed",
            subtitle = "Current speed: ${playbackSpeed}x",
            onClick = { showSpeedSheet = true },
            tag = "setting_speed"
        )

        SettingItem(
            icon = Icons.Default.Refresh,
            title = "Scan Music",
            subtitle = "Rescan device for local audio files",
            onClick = {
                viewModel.scanMusic()
                Toast.makeText(context, "Scanning local audio files...", Toast.LENGTH_SHORT).show()
            },
            tag = "setting_scan"
        )

        SettingItem(
            icon = Icons.Default.CleaningServices,
            title = "Cache Management",
            subtitle = "Clear listening history & temporary artwork cache",
            onClick = {
                viewModel.clearCache()
                Toast.makeText(context, "History and audio cache cleared", Toast.LENGTH_SHORT).show()
            },
            tag = "setting_cache"
        )

        SettingItem(
            icon = Icons.Default.Info,
            title = "About DV.JOY",
            subtitle = "Architecture, libraries, and developer info",
            onClick = { showAboutDialog = true },
            tag = "setting_about"
        )

        Spacer(modifier = Modifier.height(120.dp))
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("About DV.JOY", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("DV.JOY is a premium music player app designed with modern glassmorphism aesthetics.", color = TextSecondary, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Tech Stack:", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("• Kotlin & Jetpack Compose\n• AndroidX Media3 ExoPlayer & MediaSessionService\n• Room Database & StateFlow\n• Material Design 3 Glass Theme", color = TextSecondary, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text("Close", color = NeonCyan)
                }
            },
            containerColor = Color(0xFF0F172A)
        )
    }

    if (showEqualizerSheet) {
        ModalBottomSheet(
            onDismissRequest = { showEqualizerSheet = false },
            containerColor = Color(0xFF0F172A)
        ) {
            EqualizerContent(
                activePreset = eqPresetName,
                bands = viewModel.eqBands.collectAsState().value,
                onSelectPreset = { viewModel.setEqualizerPreset(it) },
                onBandChange = { idx, db -> viewModel.updateEqBand(idx, db) }
            )
        }
    }

    if (showSleepTimerSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSleepTimerSheet = false },
            containerColor = Color(0xFF0F172A)
        ) {
            SleepTimerContent(
                activeMinutes = sleepTimerMin,
                onSelectTimer = {
                    viewModel.setSleepTimer(it)
                    showSleepTimerSheet = false
                }
            )
        }
    }

    if (showSpeedSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSpeedSheet = false },
            containerColor = Color(0xFF0F172A)
        ) {
            SpeedContent(
                currentSpeed = playbackSpeed,
                onSelectSpeed = {
                    viewModel.setPlaybackSpeed(it)
                    showSpeedSheet = false
                }
            )
        }
    }

    if (showSecuritySheet) {
        SecuritySettingsSheet(
            securityRepository = viewModel.securityRepository,
            onDismiss = { showSecuritySheet = false }
        )
    }
}

@Composable
fun SettingItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    tag: String
) {
    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .testTag(tag),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(GlassSurface),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = NeonCyan,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column {
                Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(text = subtitle, fontSize = 12.sp, color = TextSecondary)
            }
        }
    }
}
