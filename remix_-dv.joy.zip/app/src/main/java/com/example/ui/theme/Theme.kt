package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DVJoyDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = BlackBackground,
    primaryContainer = DeepBlueAccent,
    onPrimaryContainer = IceBlue,
    secondary = ElectricBlue,
    onSecondary = Color.White,
    secondaryContainer = GlassSurfaceHighlight,
    onSecondaryContainer = IceBlue,
    tertiary = NeonCyan,
    background = BlackBackground,
    onBackground = TextPrimary,
    surface = DeepNavy,
    onSurface = TextPrimary,
    surfaceVariant = GlassSurface,
    onSurfaceVariant = TextSecondary,
    outline = GlassBorder,
    outlineVariant = TextMuted
)

private val DVJoyLightColorScheme = lightColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.White,
    primaryContainer = IceBlue,
    onPrimaryContainer = DeepNavy,
    secondary = NeonCyan,
    onSecondary = BlackBackground,
    secondaryContainer = GlassSurfaceHighlight,
    onSecondaryContainer = DeepNavy,
    tertiary = DeepBlueAccent,
    background = BlackBackground, // Maintain dark glass aesthetic as requested
    onBackground = TextPrimary,
    surface = DeepNavy,
    onSurface = TextPrimary,
    surfaceVariant = GlassSurface,
    onSurfaceVariant = TextSecondary,
    outline = GlassBorder,
    outlineVariant = TextMuted
)

@Composable
fun DVJoyTheme(
    darkTheme: Boolean = true, // Default to dark mode for glassmorphism
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DVJoyDarkColorScheme else DVJoyLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
