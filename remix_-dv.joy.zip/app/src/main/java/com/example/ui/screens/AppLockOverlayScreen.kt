package com.example.ui.screens

import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.security.LockType
import com.example.data.security.SecurityRepository
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.PinInputPad
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AppLockOverlayScreen(
    securityRepository: SecurityRepository,
    onUnlocked: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lockType by securityRepository.lockType.collectAsState()

    var activeLockMode by remember { 
        mutableStateOf(if (lockType == LockType.PATTERN) LockType.PIN else lockType) 
    }
    var enteredPin by remember { mutableStateOf("") }

    var isError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    var showForgotDialog by remember { mutableStateOf(false) }
    var recoveryAnswerText by remember { mutableStateOf("") }
    var recoveryErrorText by remember { mutableStateOf("") }

    // Biometric trigger helper
    val triggerBiometricAuth = {
        showBiometricPrompt(
            context = context,
            title = if (activeLockMode == LockType.FACE) "Face Recognition" else "Fingerprint Unlock",
            subtitle = "Authenticate to open DV.JOY Music",
            onSuccess = {
                Toast.makeText(context, "Unlocked successfully", Toast.LENGTH_SHORT).show()
                onUnlocked()
            },
            onError = { err ->
                isError = true
                errorMessage = err
                Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
            }
        )
    }

    LaunchedEffect(activeLockMode) {
        if (activeLockMode == LockType.FINGERPRINT || activeLockMode == LockType.FACE) {
            triggerBiometricAuth()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // App Logo & Title
            Image(
                painter = painterResource(id = R.drawable.img_dvjoy_logo_1784724845424),
                contentDescription = "DV.JOY Logo",
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .border(2.dp, NeonCyan, CircleShape)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "PLAY AND FEEL Security Lock",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            if (isError) {
                Text(
                    text = if (errorMessage.isNotEmpty()) errorMessage else "❌ Wrong Password!",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Red,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
                    textAlign = TextAlign.Center
                )
            } else {
                Text(
                    text = when (activeLockMode) {
                        LockType.PIN -> "Enter your 4-digit PIN"
                        LockType.FINGERPRINT -> "Touch fingerprint sensor"
                        LockType.FACE -> "Face Recognition Active"
                        else -> "Enter PIN to unlock"
                    },
                    fontSize = 14.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
                    textAlign = TextAlign.Center
                )
            }

            // Lock Input View based on Lock Mode
            when (activeLockMode) {
                LockType.PIN -> {
                    PinInputPad(
                        pinLength = 4,
                        enteredPin = enteredPin,
                        onPinChange = { pin ->
                            enteredPin = pin
                            isError = false
                            errorMessage = ""
                        },
                        onPinSubmitted = { pin ->
                            if (securityRepository.validatePin(pin)) {
                                onUnlocked()
                            } else {
                                isError = true
                                errorMessage = "❌ Wrong Password!"
                                enteredPin = ""
                                Toast.makeText(context, "Wrong Password!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        isError = isError
                    )
                }

                LockType.FINGERPRINT, LockType.FACE -> {
                    GlassmorphicCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(90.dp)
                                    .clip(CircleShape)
                                    .background(GlassSurface)
                                    .border(2.dp, NeonCyan, CircleShape)
                                    .clickable { triggerBiometricAuth() },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (activeLockMode == LockType.FACE) Icons.Default.Face else Icons.Default.Fingerprint,
                                    contentDescription = "Scan Biometric",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(54.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "Tap icon to scan ${if (activeLockMode == LockType.FACE) "Face ID" else "Fingerprint"}",
                                fontSize = 14.sp,
                                color = TextPrimary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                else -> {
                    PinInputPad(
                        pinLength = 4,
                        enteredPin = enteredPin,
                        onPinChange = { pin ->
                            enteredPin = pin
                            isError = false
                            errorMessage = ""
                        },
                        onPinSubmitted = { pin ->
                            if (securityRepository.validatePin(pin)) {
                                onUnlocked()
                            } else {
                                isError = true
                                errorMessage = "❌ Wrong Password!"
                                enteredPin = ""
                            }
                        },
                        isError = isError
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Switch Lock Mode options & Forgot Password
            Row(
                horizontalArrangement = Arrangement.SpaceEvenly,
                modifier = Modifier.fillMaxWidth()
            ) {
                // PIN Switch
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (activeLockMode == LockType.PIN) NeonCyan.copy(alpha = 0.2f) else GlassSurface)
                        .clickable {
                            activeLockMode = LockType.PIN
                            isError = false
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Pin, contentDescription = "PIN", tint = NeonCyan, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("PIN Code", fontSize = 13.sp, color = TextPrimary)
                    }
                }

                // Fingerprint Switch
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (activeLockMode == LockType.FINGERPRINT) NeonCyan.copy(alpha = 0.2f) else GlassSurface)
                        .clickable {
                            activeLockMode = LockType.FINGERPRINT
                            isError = false
                            triggerBiometricAuth()
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Fingerprint, contentDescription = "Fingerprint", tint = NeonCyan, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Fingerprint", fontSize = 13.sp, color = TextPrimary)
                    }
                }

                // Face Switch
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (activeLockMode == LockType.FACE) NeonCyan.copy(alpha = 0.2f) else GlassSurface)
                        .clickable {
                            activeLockMode = LockType.FACE
                            isError = false
                            triggerBiometricAuth()
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Face, contentDescription = "Face", tint = NeonCyan, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Face Lock", fontSize = 13.sp, color = TextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            TextButton(
                onClick = { showForgotDialog = true },
                modifier = Modifier.testTag("btn_forgot_password")
            ) {
                Text("Forgot Password / Recovery", color = NeonCyan, fontSize = 13.sp)
            }
        }
    }

    // Security Recovery Question Dialog
    if (showForgotDialog) {
        AlertDialog(
            onDismissRequest = { showForgotDialog = false },
            containerColor = DarkBackground,
            title = {
                Text(
                    text = "Password Recovery",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column {
                    Text(
                        text = "Security Question:",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = securityRepository.getSecurityQuestion(),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = NeonCyan,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = recoveryAnswerText,
                        onValueChange = {
                            recoveryAnswerText = it
                            recoveryErrorText = ""
                        },
                        placeholder = { Text("Enter your answer", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = GlassBorder
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (recoveryErrorText.isNotEmpty()) {
                        Text(
                            text = recoveryErrorText,
                            fontSize = 12.sp,
                            color = Color.Red,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (securityRepository.validateSecurityAnswer(recoveryAnswerText)) {
                            Toast.makeText(context, "Recovery successful! Lock bypassed.", Toast.LENGTH_LONG).show()
                            showForgotDialog = false
                            onUnlocked()
                        } else {
                            recoveryErrorText = "Incorrect answer! Please try again."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("Verify Answer", color = DarkBackground, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showForgotDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

private fun showBiometricPrompt(
    context: Context,
    title: String,
    subtitle: String,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    val activity = context as? FragmentActivity
    if (activity == null) {
        onSuccess()
        return
    }

    val executor = ContextCompat.getMainExecutor(context)
    val biometricPrompt = BiometricPrompt(
        activity,
        executor,
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                val notMatchedMsg = if (title.contains("Face", ignoreCase = true)) {
                    "❌ Face is not matched!"
                } else {
                    "❌ Fingerprint is not matched!"
                }
                onError(notMatchedMsg)
            }

            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                val notMatchedMsg = if (title.contains("Face", ignoreCase = true)) {
                    "❌ Face is not matched!"
                } else {
                    "❌ Fingerprint is not matched!"
                }
                onError(notMatchedMsg)
            }
        }
    )

    val promptInfo = BiometricPrompt.PromptInfo.Builder()
        .setTitle(title)
        .setSubtitle(subtitle)
        .setNegativeButtonText("Use PIN Code")
        .build()

    val biometricManager = BiometricManager.from(context)
    val canAuthenticate = biometricManager.canAuthenticate(
        BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
    )

    if (canAuthenticate == BiometricManager.BIOMETRIC_SUCCESS) {
        biometricPrompt.authenticate(promptInfo)
    } else {
        val notMatchedMsg = if (title.contains("Face", ignoreCase = true)) {
            "❌ Face is not matched! (Biometric hardware unavailable)"
        } else {
            "❌ Fingerprint is not matched! (Biometric hardware unavailable)"
        }
        onError(notMatchedMsg)
    }
}
